import json
import plotly
import pandas as pd

from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize

from flask import Flask
from flask import render_template, request, jsonify
from plotly.graph_objs import Bar
from sqlalchemy import create_engine
import joblib
from transformation import tokenize,multi_class_score
# from ../models/transformation import tokenize,multi_class_score

app = Flask(__name__)

# load data
engine = create_engine('sqlite:///../data/DisasterResponse.db')
df = pd.read_sql_table('message_table', engine)

# load model
model = joblib.load("../models/classifier.pkl")
# model = joblib.load("../models/classifier.pkl")


# index webpage displays cool visuals and receives user input text for model
@app.route('/')
@app.route('/index')
def index():
    """
        Extracts data needed for visuals and creates Plotly graphs.

        This function extracts data for visualizations, such as the distribution of message genres and the top 10 responses.
        It then creates Plotly bar graphs and encodes them in JSON format for rendering in a web page.

        Returns:
        str: Rendered HTML template with embedded Plotly graphs.
    """
    # extract data needed for visuals
    # TODO: Below is an example - modify to extract data for your own visuals
    genre_counts = df.groupby('genre').count()['message']
    genre_names = list(genre_counts.index)
   

    Y = df.drop(['id', 'message', 'original', 'genre'], axis = 1)
    top_response_counts = Y.sum(axis=0).sort_values(ascending=False)[:10]
    top_response_names = list(top_response_counts.index)
    # create visuals
    # TODO: Below is an example - modify to create your own visuals
    graphs = [
        {
            'data': [
                Bar(
                    x=genre_names,
                    y=list(genre_counts)
                )
            ],

            'layout': {
                'title': 'Distribution of Message Genres',
                'yaxis': {
                    'title': "Count"
                },
                'xaxis': {
                    'title': "Genre"
                }
            }
        },

         {
            'data': [
                Bar(
                    x=top_response_names,
                    y=list(top_response_counts)
                )
            ],

            'layout': {
                'title': 'Top 10 Responses',
                'yaxis': {
                    'title': "Count"
                },
                'xaxis': {
                    'title': "Response"
                }
            }
        }
    ]
    
    # encode plotly graphs in JSON
    ids = ["graph-{}".format(i) for i, _ in enumerate(graphs)]
    graphJSON = json.dumps(graphs, cls=plotly.utils.PlotlyJSONEncoder)
    
    # render web page with plotly graphs
    return render_template('master.html', ids=ids, graphJSON=graphJSON)


# web page that handles user query and displays model results
@app.route('/go')
def go():
    """
        Handles user query and displays model results.

        This function saves the user input query, uses a model to predict classifications for the query,
        and renders the results in an HTML template.

        Returns:
        str: Rendered HTML template with classification results.
    """
    # save user input in query
    query = request.args.get('query', '') 

    # use model to predict classification for query
    classification_labels = model.predict([query])[0]
    classification_results = dict(zip(df.columns[4:], classification_labels))
    # This will render the go.html Please see that file. 
    return render_template(
        'go.html',
        query=query,
        classification_result=classification_results
    )


def main():
    """
    Runs the Flask web application.

    This function starts the Flask web server on the specified host and port with debug mode enabled.

    Returns:
    None
    """

    app.run(host='0.0.0.0', port=3001, debug=True)


if __name__ == '__main__':
    main()