import re
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
from nltk.stem.wordnet import WordNetLemmatizer
from sklearn.metrics import accuracy_score
import numpy as np

def tokenize(text):
    """
        Normalize, tokenize, and stem/lemmatize text.

        Args:
        text: str. Text to be processed.

        Returns:
        words: list of str. List of processed words.
        """
    # Normalize text
    text = re.sub(r"[^a-zA-Z0-9]", " ", text.lower())
    # Tokenize text
    words = word_tokenize(text)
    words = [w for w in words if w not in stopwords.words("english")]
    # Reduce words to their stems
    words = [PorterStemmer().stem(w) for w in words]
    words = [WordNetLemmatizer().lemmatize(w) for w in words]
    return words


def multi_class_score(y_true, y_pred):
    """
       Calculate the average accuracy score for multi-class classification.

       Args:
       y_true: DataFrame. True labels.
       y_pred: ndarray. Predicted labels.

       Returns:
       avg_accuracy: float. Average accuracy score.
       """
    accuracy_results = []
    for i, column in enumerate(y_true.columns):
        accuracy = accuracy_score(
            y_true.loc[:, column].values, y_pred[:, i])
        accuracy_results.append(accuracy)
    avg_accuracy = np.mean(accuracy_results)
    return avg_accuracy